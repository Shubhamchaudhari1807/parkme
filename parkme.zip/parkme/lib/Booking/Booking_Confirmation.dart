import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:parkme/booking/BookingSuccessful.dart';
import 'package:parkme/constant.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:twilio_flutter/twilio_flutter.dart';

class BookingConfirmation extends StatefulWidget {
  QueryDocumentSnapshot? spot;

  BookingConfirmation({Key? key, this.spot}) : super(key: key);

  @override
  _BookingConfirmationState createState() => _BookingConfirmationState();
}

class _BookingConfirmationState extends State<BookingConfirmation> {
  TimeOfDay? _checkInTime, _checkOutTime;
  DateTime? _date;
  String? dropdownValue = null;
  DateFormat? formatter = DateFormat('dd-MM-yyyy');
  int? currentOccupiedSpots;
  List? _vehicles = [];
  Razorpay? _razorpay = Razorpay();
  TwilioFlutter? twilioFlutter;

  @override
  void initState() {
    _initUserVehicles();
    _checkInTime = TimeOfDay.now();
    _checkOutTime = TimeOfDay.now();
    _date = DateTime.now();
    _razorpay?.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay?.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay?.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    twilioFlutter = TwilioFlutter(
        accountSid: 'AC16349c4744d628ebdf84e7a6c20bbe40',
        authToken: 'ba9ea67f7d1abb16b12826085b537050',
        twilioNumber: '+15316252481');
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay?.clear();
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Container(
                  margin: EdgeInsetsDirectional.only(top: 5),
                  height: height * 0.35,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage(
                          Uri.tryParse(widget.spot!['imageUrl'] ?? "")
                              .toString()),
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
                Positioned(
                  top: 250,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 200,
                    decoration: BoxDecoration(
                        color: kprimaryBgColor,
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(15),
                            topRight: Radius.circular(15))),
                  ),
                ),
                Positioned(
                  top: 50,
                  left: 20,
                  child: CircleAvatar(
                    radius: 20,
                    backgroundColor: kprimaryBgColor,
                    child: Center(
                      child: GestureDetector(
                        child: Icon(Icons.arrow_back, color: kprimaryColor),
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Container(
              height: height * 0.60,
              decoration: BoxDecoration(
                color: kprimaryBgColor,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Column(
                          children: [
                            Hero(
                              tag: 'centerName',
                              child: Text(
                                widget.spot?['name'] ?? "",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: kprimaryColor,
                                    fontSize: 20),
                              ),
                            ),
                            Row(
                              children: [
                                Icon(
                                  Icons.location_on,
                                  size: 18,
                                ),
                                Text(
                                  widget.spot?['address'] ?? "",
                                  style: TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.only(top: 12, bottom: 10),
                          height: 30,
                          width: 150,
                          child: Center(
                            child: Text(
                              '${(widget.spot!['totalSpots'] ?? 0) - (widget.spot!['occupiedSpots'] ?? 0)} slots available',
                              style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          decoration: BoxDecoration(
                              color: Colors.red.shade100,
                              borderRadius: BorderRadius.circular(5)),
                        ),
                      ],
                    ),
                    Text(
                      '\u{20B9} ${widget.spot?['costPerHour'] ?? 0.00} per hour',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 15, bottom: 20),
                      child: Divider(color: Colors.grey),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Check-in',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                TimeOfDay? time = await showTimePicker(
                                    context: context,
                                    initialTime: _checkInTime!);
                                setState(() {
                                  if (time != null) {
                                    _checkInTime = time;
                                  }
                                });
                              },
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 5),
                                width: width * 0.3,
                                height: 65,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(5)),
                                child: Text(
                                  "${_checkInTime!.hour < 10 ? '0${_checkInTime!.hour}' : _checkInTime!.hour}:${_checkInTime!.minute < 10 ? '0${_checkInTime!.minute}' : _checkInTime!.minute}",
                                  style: TextStyle(
                                      fontSize: 35,
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                            ),
                            Text(
                              '(Tap to edit)',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey.shade500),
                            )
                          ],
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              'Check-out',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                              ),
                            ),
                            GestureDetector(
                              onTap: () async {
                                TimeOfDay? time = await showTimePicker(
                                    context: context,
                                    initialTime: _checkOutTime!);
                                setState(() {
                                  if (time != null) {
                                    _checkOutTime = time;
                                  }
                                });
                              },
                              child: Container(
                                margin: EdgeInsets.symmetric(vertical: 5),
                                width: width * 0.3,
                                height: 65,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    color: Colors.grey.shade200,
                                    borderRadius: BorderRadius.circular(5)),
                                child: Text(
                                  "${_checkOutTime!.hour < 10 ? '0${_checkOutTime!.hour}' : _checkOutTime!.hour}:${_checkOutTime!.minute < 10 ? '0${_checkOutTime!.minute}' : _checkOutTime!.minute}",
                                  style: TextStyle(
                                      fontSize: 35,
                                      fontWeight: FontWeight.w400),
                                ),
                              ),
                            ),
                            Text(
                              '(Tap to edit)',
                              style: TextStyle(
                                  fontSize: 12, color: Colors.grey.shade500),
                            )
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 40,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 5),
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          width: width,
                          decoration: BoxDecoration(
                              color: Colors.grey.shade200,
                              borderRadius: BorderRadius.circular(5)),
                          child: Center(
                            child: DropdownButton<String>(
                              hint: dropdownValue == null
                                  ? Text('Choose Vehicle')
                                  : Text(
                                      dropdownValue ?? "N/A",
                                    ),
                              isExpanded: true,
                              icon: const Icon(Icons.arrow_drop_down),
                              iconSize: 30,
                              elevation: 24,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400),
                              underline: Container(
                                height: 2,
                                color: Colors.grey.shade200,
                              ),
                              onChanged: (newValue) {
                                setState(() {
                                  dropdownValue = newValue;
                                });
                              },
                              items: <String>[
                                ...?_vehicles
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Column(
                      children: [
                        Text(
                          'Total Charges',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 14,
                              fontWeight: FontWeight.w400),
                        ),
                        Text(
                          '\u{20B9} ${((((_checkOutTime?.hour ?? 0) * 60 + (_checkOutTime?.minute ?? 0)) - ((_checkInTime?.hour ?? 0) * 60 + (_checkInTime?.minute ?? 0))) / 60 * (widget.spot!['costPerHour'] ?? 0)).round()}',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    // SizedBox(
                    //   height: 10,
                    // ),
                  ],
                ),
              ),
            ),
            Row(
              children: <Widget>[
                Container(
                  width: width * 0.5,
                  height: 60,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.all(10),
                      backgroundColor: Colors.grey.shade200,
                      // Background color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0.0),
                      ),
                      splashFactory: InkSplash.splashFactory,
                    ),
                    child: const Text(
                      'PAY AT LOCATION',
                      style: TextStyle(color: Colors.black, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                      if (dropdownValue == null) {
                        Fluttertoast.showToast(
                          msg: "Please Select Vehicle",
                          timeInSecForIosWeb: 4,
                        );
                      } else if (((_checkOutTime?.hour ?? 0) * 60 +
                              (_checkOutTime?.minute ?? 0) -
                              ((_checkInTime?.hour ?? 0) * 60 +
                                  (_checkInTime?.minute ?? 0))) <=
                          0) {
                        Fluttertoast.showToast(
                          msg: "Please Select Appropriate Time",
                          timeInSecForIosWeb: 4,
                        );
                      } else {
                        addReservationToFirebase(false, null);
                      }
                    },
                  ),
                ),
                Container(
                  width: width * 0.5,
                  height: 60,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.all(10),
                      backgroundColor: kprimaryColor,
                      // Background color
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(0.0),
                      ),
                      splashFactory: InkSplash.splashFactory,
                    ),
                    child: const Text(
                      'PAY NOW',
                      style: TextStyle(color: Colors.white, fontSize: 16),
                      textAlign: TextAlign.center,
                    ),
                    onPressed: () {
                      if (dropdownValue == null) {
                        Fluttertoast.showToast(
                          msg: "Please Select Vehicle",
                          timeInSecForIosWeb: 4,
                        );
                      } else if (((_checkOutTime?.hour ?? 0) * 60 +
                              (_checkOutTime?.minute ?? 0) -
                              ((_checkInTime?.hour ?? 0) * 60 +
                                  (_checkInTime?.minute ?? 0))) <=
                          0) {
                        Fluttertoast.showToast(
                          msg: "Please Select Appropriate Time",
                          timeInSecForIosWeb: 4,
                        );
                      } else {
                        openCheckout();
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _initUserVehicles() {
    FirebaseFirestore.instance
        .collection('vehicles')
        .where("uid", isEqualTo: FirebaseAuth.instance.currentUser?.uid ?? "")
        .get()
        .then(
      (value) {
        value.docs.forEach((vehicle) {
          _vehicles!.add(vehicle['vehicleNumber']);
        });
        setState(() {
          _vehicles = [...?_vehicles];
        });
      },
    );
  }

  void openCheckout() async {
    int checkOutAmount =
        (((((_checkOutTime?.hour ?? 0) * 60 + (_checkOutTime?.minute ?? 0)) -
                        ((_checkInTime?.hour ?? 0) * 60 +
                            (_checkInTime?.minute ?? 0))) /
                    60) *
                (widget.spot?['costPerHour'] ?? 0))
            .round();
    print(checkOutAmount);
    var options = {
      'key': 'rzp_test_M5BGoCTvBT4zcT',
      'amount': checkOutAmount * 100,
      'name': FirebaseAuth.instance.currentUser!.displayName,
      'description': 'Payment of Parking Spot',
      'prefill': {'email': FirebaseAuth.instance.currentUser!.email},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay!.open(options);
    } catch (e) {
      print("Failed to open razorpay: $e");
      Fluttertoast.showToast(msg: "Failed to open razorpay.Please try again.");
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse? response) {
    Fluttertoast.showToast(
        msg: "SUCCESS: ${response?.paymentId ?? ""}", timeInSecForIosWeb: 4);
    addReservationToFirebase(true, response?.paymentId ?? "");
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
        msg: "ERROR: ${response.code} - ${response.message}",
        timeInSecForIosWeb: 4);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: ${response.walletName}", timeInSecForIosWeb: 4);
  }

  void addReservationToFirebase(bool paymentDone, String? transactionID) {
    CollectionReference reservations =
    FirebaseFirestore.instance.collection('reservations');
    CollectionReference parkingCentres =
    FirebaseFirestore.instance.collection('parkingCentres');

    // Ensure current user is available
    String userId = FirebaseAuth.instance.currentUser?.uid ?? 'Unknown User';

    // Prepare reservation data
    reservations.add({
      'centre': widget.spot?['name'] ?? 'Unknown Centre',
      'vehicleNumber': dropdownValue ?? 'Unknown Vehicle',
      'date': formatter?.format(_date!) ?? 'Unknown Date',
      'checkin':
      "${(_checkInTime?.hour ?? 0).toString().padLeft(2, '0')}:${(_checkInTime?.minute ?? 0).toString().padLeft(2, '0')}",
      'checkout':
      "${(_checkOutTime?.hour ?? 0).toString().padLeft(2, '0')}:${(_checkOutTime?.minute ?? 0).toString().padLeft(2, '0')}",
      'cost': '${(((((_checkOutTime?.hour ?? 0) * 60 + (_checkOutTime?.minute ?? 0)) - ((_checkInTime?.hour ?? 0) * 60 + (_checkInTime?.minute ?? 0))) / 60) * (widget.spot?['costPerHour'] ?? 0)).round()}',
      'paymentMethod': paymentDone ? 'Online' : 'On Arrival',
      'transactionID': transactionID,
      'uid': userId,
    }).then((value) {
      // Get and update current occupied spots
      int currentOccupiedSpots = (widget.spot?['occupiedSpots'] ?? 0) + 1;
      parkingCentres
          .doc('${widget.spot?['id']}')
          .update({'occupiedSpots': currentOccupiedSpots});

      // Send SMS notification
      twilioFlutter?.sendSMS(
        toNumber: '+918080970288',
        messageBody:
        'Parking Spot at ${widget.spot?['name'] ?? 'Unknown Centre'} successful. Thanks for using Park ME.',
      );

      // Navigate to BookingSuccessful screen
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) {
            return BookingSuccessful(data: {
              'ticketID': value.id,
              'vehicleNumber': dropdownValue ?? 'Unknown Vehicle',
              'centre': widget.spot?['name'] ?? 'Unknown Centre',
              'date': formatter?.format(_date!) ?? 'Unknown Date',
              'transactionID': transactionID ?? '',
              'checkin':
              "${(_checkInTime?.hour ?? 0).toString().padLeft(2, '0')}:${(_checkInTime?.minute ?? 0).toString().padLeft(2, '0')}",
              'checkout':
              "${(_checkOutTime?.hour ?? 0).toString().padLeft(2, '0')}:${(_checkOutTime?.minute ?? 0).toString().padLeft(2, '0')}",
              'cost':
              '${(((((_checkOutTime?.hour ?? 0) * 60 + (_checkOutTime?.minute ?? 0)) - ((_checkInTime?.hour ?? 0) * 60 + (_checkInTime?.minute ?? 0))) / 60) * (widget.spot?['costPerHour'] ?? 0)).round()}',
            });
          },
        ),
      );
    }).catchError((error) => print("Failed to do reservation: $error"));
  }

}

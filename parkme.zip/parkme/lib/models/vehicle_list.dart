class VehicleData {
  var id;
  String? title;
  String? url;
  String? thumbnail;
  String? owner;
  String? vehicleNumber;

  VehicleData({this.id,this.title,this.url,this.thumbnail,this.owner,this.vehicleNumber});
}
class ParkingSpot {
  int? id;
  String? name;
  String? address;
  var totalSpots;
  var occupiedSpots;
  String? imageUrl;
  double? costPerHour;
  var owner;

  ParkingSpot(
      {this.id, this.name, this.address, this.totalSpots, this.occupiedSpots});
}

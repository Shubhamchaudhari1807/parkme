import 'package:flutter/material.dart';

Color primaryBlack = Color(0xff202c3b);
class DataSource {
  static List questionAnswers = [
    {
      "question": "What is a ParkMe?",
      "answer": "Lorem Ipsum"
    },
    {
      "question": "How to find a Parking spot?",
      "answer": "Lorem Ipsum"
    },
    {
      "question": "What is the privacy policy?",
      "answer": "Lorem Ipsum"
    },
  ];
}

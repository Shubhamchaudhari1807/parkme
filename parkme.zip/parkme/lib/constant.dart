//To store the colors used in the app

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:platform_info/platform_info.dart';
import 'package:flutter/foundation.dart' show kDebugMode;

Color kprimaryColor = Color(0xFF03C197);
Color ksecondaryColor = Color(0xFF4A4A4A);
Color kprimaryBgColor = Colors.white;
Color kBtnTextColor = Colors.white;

class Constants {
  static Future<bool> isFirstTime(String? str) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? firstTime = prefs.getBool(str ?? "CommonFirstTime") ?? true;
    if (firstTime) {
      // first time
      await prefs.setBool(str ?? "CommonFirstTime", false);
      return true;
    } else {
      return false;
    }

    return false;
  }

/*
  //Usage
  Constants.isFirstTime("ConstantUniqueKey").then((isFirstTime) {
  if(isFirstTime==true){
  print("First time");
  }else{
  print("Not first time");
  }
  });
  */

  static bool isMobileApp() {
    try {
      if (platform.mobile == true) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  static bool isAndroid() {
    try {
      if (platform.android == true) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return false;
      // print(e);
    }
  }

  static bool isIOS() {
    try {
      if (platform.iOS == true) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  static bool isMacOS() {
    try {
      if (platform.macOS == true) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  static bool isFuchsia() {
    try {
      if (platform.fuchsia == true) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      print(e);
      return false;
    }
  }

  static Future<String> getCurrentPlatform() async {
    try {
      if (platform.type == HostPlatformType.js()) {
        return "web";
      } else if (platform.macOS) {
        return "macOS";
      } else if (platform.linux) {
        return "Linux";
      } else if (platform.windows) {
        return "Windows";
      } else if (platform.android) {
        return "Android";
      } else if (platform.iOS) {
        return "iOS";
      } else if (platform.fuchsia) {
        return "Fuchsia";
      } else if (platform.unknown) {
        return "Unknown platform";
      } else {
        return "Unknown platform";
      }
    } catch (e) {
      print(e);
      return "Unknown platform";
    }
  }

  ///print log at platform  level
  static void debugLog(Type? classObject, String? message) {
    try {
      var runtimeTypeName = (classObject).toString();
      if (kDebugMode) {
        // print("${runtimeTypeName.toString()}: $message");
        debugPrint("${runtimeTypeName.toString()}: $message");
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  /*
  * * Usage
  * * Constants.debugLog(SplashScreen,"Hello");
  *
  */

  static Future<String> getCurrentPlatformBuildMode() async {
    try {
      final String buildMode = switch (platform.buildMode) {
        BuildMode$Debug _ => 'Debug',
        BuildMode$Profile _ => 'Profile',
        BuildMode$Release _ => 'Release',
      };
      Constants.debugLog(
          Constants, "getCurrentPlatformBuildMode:buildMode:$buildMode");
      return buildMode;
    } catch (e) {
      return "Unknown platform";
    }
  }

  static Future<Position?> getCurrentLocation(
      {BuildContext? context, LocationAccuracy? desiredAccuracy}) async {
    PermissionStatus? permission;
    bool serviceEnabled;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return await Geolocator.openLocationSettings().then((value) async {
        return await getCurrentLocation(
            context: context, desiredAccuracy: desiredAccuracy);
      });
    }

    permission = await Permission.location.status;

    if (permission == PermissionStatus.permanentlyDenied) {
      if (Constants.isMobileApp()) {
        showDialog(
          context: context!,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Location permissions required'),
              content: const Text(
                  'Please go to app settings and grant location permissions.'),
              actions: <Widget>[
                TextButton(
                  child: const Text('CANCEL'),
                  onPressed: () => Navigator.pop(context),
                ),
                TextButton(
                  child: const Text('OPEN APP SETTINGS'),
                  onPressed: () {
                    Navigator.pop(context);
                    Geolocator.openAppSettings().then(
                      (value) => getCurrentLocation(
                          context: context, desiredAccuracy: desiredAccuracy),
                    );
                  },
                ),
              ],
            );
          },
        );
      } else {
        return Future.error('Location permissions are denied.');
      }
    } else if (permission == PermissionStatus.denied) {
      // The user has denied location permissions.
      permission = await Permission.location.request();
      if (permission == PermissionStatus.granted) {
        return await getCurrentLocation(
            context: context, desiredAccuracy: desiredAccuracy);
      } else {
        return Future.error('Location permissions are denied.');
      }
    }
    // Get the current location.
    return await Geolocator.getCurrentPosition(
        forceAndroidLocationManager: Constants.isAndroid(),
        desiredAccuracy: LocationAccuracy.medium);
  }
}
